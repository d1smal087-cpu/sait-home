@echo off
setlocal
set "rollback_python=%~dp0.venv\Scripts\python.exe"
if not exist "%rollback_python%" (
    echo Extract this rollback into your EXISTING LU4 Observer folder, next to .venv.
    pause
    exit /b 1
)
if not exist "%~dp0rollback-0.1.7\test_controls.py" (
    echo Missing original 0.1.7 files. Extract the complete rollback ZIP.
    pause
    exit /b 1
)
cd /d "%~dp0rollback-0.1.7"
echo ORIGINAL 0.1.7 F2 TEST. In LU4, bind NEXT TARGET to F2 again.
echo Keep chat CLOSED and remove the current target with Esc before the countdown ends.
"%rollback_python%" test_controls.py --countdown 10 --key-mode scan --hold-ms 300
set "rollback_exit=%errorlevel%"
echo.
echo Original 0.1.7 test ended. Log is in rollback-0.1.7\runs.
pause
exit /b %rollback_exit%
